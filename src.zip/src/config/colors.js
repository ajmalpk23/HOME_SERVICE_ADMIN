export default{
    primarycolor: '#333458',
    backgroundcolor : '#ffffff',
    continercolor:'rgba(51, 52, 88, 0.06)',
    offercard:'#6FCF97',
    secondaryText:'#5F5F82',
    green:'#6FCF97'

}